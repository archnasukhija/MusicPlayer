//
//  MusicListViewModel.swift
//  MusicPlayerApp
//
//  Created by Archna Sukhija on 25/10/23.
//

import Foundation

protocol MusicListViewModelProtocol {
    var songs: [Song]? { get set }
    func fetchMusicListing(completion:  @escaping ([Song]?) -> Void)
}

class MusicListViewModel: MusicListViewModelProtocol {
    var songs: [Song]?

    func fetchMusicListing(completion: @escaping ([Song]?) -> Void) {
       // let url = URL(string: "https://jsonkeeper.com/b/T0NQ")
//        if let url = url {
//            let urlRequest = URLRequest(url: url)
//            URLSession.shared.dataTask(with: urlRequest) { data, response, error in
//                if let data = data {
//                    let songs = try? JSONDecoder().decode([Song].self, from: data)
//                    self.songs = songs
//                    completion(songs)
//                }
//
//            }.resume()
//        }

        if let path = Bundle.main.path(forResource: "MockData", ofType: "json") {
            do {
                let data = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let data = data {
                    let musicListResponse = try? JSONDecoder().decode(MusicListResponse.self, from: data)
                    self.songs = musicListResponse?.songs
                    completion(songs)
                }
            }
        }


        }

    }

