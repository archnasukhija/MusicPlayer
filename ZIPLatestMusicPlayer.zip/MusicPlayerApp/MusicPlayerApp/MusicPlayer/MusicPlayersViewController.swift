//
//  MusicPlayersViewController.swift
//  MusicPlayerApp
//
//  Created by Archna Sukhija on 25/10/23.
//

import UIKit
import AVFoundation

class MusicPlayersViewController: UIViewController {

    var currentSelectedSong: Song?
    var allSongs: [Song]?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func playNextSong(_ sender: Any) {
    }
    @IBAction func playPrevSong(_ sender: Any) {
    }
    @IBAction func playSong(_ sender: Any) {
    }
    func playNextSong() {

    }

    func playPreviousSong() {

    }

    func playSong() {

    }

}

class MusicPlayer {
    var currentPlayBackItem: AVPlayerItem
    var avplayer: AVPlayer?

    init(url: URL) {
        self.avplayer = AVPlayer(url: url)
        self.avplayer?.play()
    }

    var player = AVPlayer(url: <#T##URL#>)
}
