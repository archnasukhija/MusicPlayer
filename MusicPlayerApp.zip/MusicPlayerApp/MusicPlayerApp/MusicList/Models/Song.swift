//
//  Song.swift
//  MusicPlayerApp
//
//  Created by Archna Sukhija on 25/10/23.
//

import Foundation

struct MusicListResponse: Codable {
    var songs: [Song]
}

struct Song: Codable {
    var title: String
    var artist: String
    var album: String
    var url: String
}
