//
//  MusicListViewController.swift
//  MusicPlayerApp
//
//  Created by Archna Sukhija on 25/10/23.
//

import UIKit

struct Constants {
   static let cellIdentifier = "MusicListTableViewCell"
}

class MusicListViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    var viewModel: MusicListViewModelProtocol = MusicListViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadData()
        // Do any additional setup after loading the view.
    }

    func loadData() {
        self.registerNib()
        self.viewModel.fetchMusicListing(completion: { songs in
            self.tblView.reloadData()
        })

        self.navigationItem.title = "Music List"
    }

    func registerNib() {
        let nib = UINib(nibName: Constants.cellIdentifier, bundle: nil)
        tblView.register(nib, forCellReuseIdentifier: Constants.cellIdentifier)
    }


}

extension MusicListViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.songs?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tblView.dequeueReusableCell(withIdentifier: Constants.cellIdentifier, for: indexPath) as? MusicListTableViewCell else {
            return UITableViewCell()
        }
        cell.configureCell(song: viewModel.songs?[indexPath.row])
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }

    
}


