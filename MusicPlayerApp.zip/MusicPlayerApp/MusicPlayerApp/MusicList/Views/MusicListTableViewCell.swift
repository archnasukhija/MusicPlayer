//
//  MusicListTableViewCell.swift
//  MusicPlayerApp
//
//  Created by Archna Sukhija on 25/10/23.
//

import UIKit

class MusicListTableViewCell: UITableViewCell {

    @IBOutlet weak var lblArtistAlbum: UILabel!
    @IBOutlet weak var lblSongName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func configureCell(song: Song?) {
        guard let song = song else {
            return
        }
        self.lblSongName.text = song.title
        self.lblArtistAlbum.text = "\(song.artist) - \(song.album)"
    }
    
}
